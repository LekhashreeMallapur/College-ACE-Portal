import React from 'react'

const GuestDashboard = () => {
  return (
    <div className='h-screen flex justify-center items-center text-7xl font-extrabold'>⚠️ Page Under Construction ⚠️</div>
  )
}

export default GuestDashboard