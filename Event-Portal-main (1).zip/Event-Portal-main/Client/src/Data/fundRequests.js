const fundRequests = [
    {
        id: 1,
        name: 'Asteria',
        description: 'Lorem ipsum dolor sit am id, consectetur adipiscing el',
        funds: 9999
    },
    {
        id: 2,
        name: 'KLE Food Fest',
        description: 'Lorem ipsum dolor sit am id, consectetur adipiscing el',
        funds: 91009
    },
    {
        id: 3,
        name: 'Avengers Endgame',
        description: 'Lorem ipsum dolor sit am id, consectetur adipiscing el',
        funds: 1089
    },
]

export default fundRequests